using System;

class Program
{
    static void Main(string[] args)
    {
        int A, B, C, D;
        try
        {   Console.Write("A = ");
            A = Convert.ToInt32(Console.ReadLine());
            Console.Write("B = ");
            B = Convert.ToInt32(Console.ReadLine());
            Console.Write("C = ");
            C = Convert.ToInt32(Console.ReadLine());
        }
        catch
        {   Console.WriteLine("Invalid input");
            return;
        }
        if (A == 0)
        {   Console.WriteLine("Not a quadratic equation.");
            return;
        }
        D = B * B - 4 * A * C;
        if (D == 0)
            Console.WriteLine("x = {0}", -B / 2.0 / A);
        else if (D > 0)
            Console.WriteLine("x1 = {0}\nx2 = {1}", (-B + Math.Sqrt(D)) / 2 / A, (-B - Math.Sqrt(D)) / 2 / A);
        else
            Console.WriteLine("x1 = ({0},{1})\nx2 = ({0},-{1})", -B/2.0/A, Math.Sqrt(-D)/2/A);
    }
}
