#include "stdio.h"

__int64 factorial(__int64 n)
{
	return ( n==0 ? 1 : n*factorial(n-1) );
}

int main(int argc, char* argv[])
{
	for (int n=0; n<=16; n++)
		printf( "%d! = %I64d\n", n, factorial(n) );
	return 0;
}
