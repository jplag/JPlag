import math
import sys

A = float(raw_input("A = "))
if A == 0:
    print "Not a quadratic equation"
    sys.exit()

B = float(raw_input("B = "))
C = float(raw_input("C = "))

D = B * B - 4 * A * C
if D == 0:
    print "x =", -B / 2.0 / A
    sys.exit()
if D > 0: 
    print "x1 =", (-B + math.sqrt(D)) / 2.0 / A
    print "x2 =", (-B - math.sqrt(D)) / 2.0 / A
else:
    print "x1 = (", -B / 2.0 / A, ",", math.sqrt(-D) / 2.0 / A, ")"
    print "x2 = (", -B / 2.0 / A, ",", -math.sqrt(-D) / 2.0 / A, ")"
