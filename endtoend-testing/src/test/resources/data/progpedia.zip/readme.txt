Comparison 1 bis 91 in result-bc-t15 sind plagiate.
Menschlich geprüft und dann in plagiate.csv persistiert


Dataset: Nur ACCEPTED, muss mit -bc base gerunnt werden!